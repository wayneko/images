﻿/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleMenu.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script creates menu for Changing Styles
 *     
 **************************************************************************/ 
#include "./ChangeStyle/ChangeStyleUI.jsx"
#include "./ChangeStyle/ChangeStyleUtils.jsx"
#include "./ChangeStyle/BookIterator.jsx"
#include "./ChangeStyle/ChangeStyleParaTags.jsx"
#include "./ChangeStyle/ChangeStyleTableTags.jsx"
#include "./ChangeStyle/ChangeStyleCharTags.jsx"


/*Global*/
var paraCount = 0 
var charCount = 0
var tblCount = 0
var fileWasAlreadyOpen = false
var iniTag = ""
var finalTag = ""
var type = ""   //   ----  para/char/tbl


AddStyleMenu()

function Command(cmd)
{	
	switch(cmd)
    {	
		case 1: 
		
            var Builder = createDlg ()
            var active = findActive () 
            if(active == null)
                return
           
            initializeBuilder(Builder);

 // Show the user-input dialog, and save the returned resource string
            if (runBuilder(Builder) == 1 ){exit}
                break;
      }
}
/*This function adds menu Change Styles... to File-->Utilities Menu*/
function AddStyleMenu()
{
    
    var NewCommand = DefineCommand(1,"Change Styles...","Change Styles...","")
 
    var mMenu = app.GetNamedMenu("UtilitiesMenu")
    var bMenu = app.GetNamedMenu("BookUtilitiesMenu")
    
    var nMenu = mMenu.AddCommandToMenu(NewCommand)
    var cMenu = bMenu.AddCommandToMenu(NewCommand)
    
    UpdateMenus()
}
