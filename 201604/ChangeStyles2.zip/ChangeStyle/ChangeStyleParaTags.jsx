﻿/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleParaTags.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script contains functions to change paragraph tags
 *     
 **************************************************************************/ 

/*This function changes the paragraph tags in the document in all flows.*/

 function changeParaTag(active)
{
         
    if(active.BookIsSelected || active.FirstSelectedComponentInBook) 
        iterateBook(active);
    else if(active.ObjectValid())
        {  
                   var flow = active.FirstFlowInDoc
                   var firstPgf = flow.FirstTextFrameInFlow.FirstPgf
                   
                            var textLoc = new TextLoc(firstPgf,0)
                            var pgfId = textLoc.obj;
                            
                                while(pgfId.ObjectValid())	
                                {   
                                       
                                        if((pgfId.ObjectValid()) && (finalTag != "") && (pgfId.Name == iniTag))
                                      {
                                            textpgf = pgfId.GetText (Constants.FTI_String)
                                            if(textpgf.length != 0 && !isTableInReferenceOrHiddenPageOrMasterPage(textLoc))
                                                setPgfTagOfPgf(active,pgfId)
                                      }
                                   
                                        var newpara =  firstPgf.NextPgfInDoc
                                        textLoc = new TextLoc(newpara,0);
                                        pgfId = textLoc.obj;
                                        firstPgf = newpara;
                                  }      
                            
                    //    savedoc(active);   
          }
    
}
   

/*This function changes the para tag for the specific paragraph*/

function setPgfTagOfPgf(active,currpgf)
{  
   if(finalTag != "")
    {
        		
        var pgfFmt = active.GetNamedPgfFmt(finalTag);     
		
		if((currpgf.GetProps() != pgfFmt.GetProps())&& (pgfFmt.ObjectValid()))
		{   
            paraCount++                                                                
            currpgf.SetProps(pgfFmt.GetProps())
          } 

    }
return;
}