﻿
/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleTableTags.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script contains functions to change table format
 *     
 **************************************************************************/ 

/*This function changes the Table format in all the flows in the document*/

function changeTblTag(active)
{
        
    if(active.BookIsSelected || active.FirstSelectedComponentInBook) 
        iterateBook(active);
    else if(active.ObjectValid())
        {
                        var flow = active.FirstFlowInDoc;
                        while(flow.ObjectValid())        
                        {
                            var i = 0;
                            var textItems = flow.GetText(Constants.FTI_TblAnchor) // Get all tables in the flow
                            
                            var newtblfmt = active.GetNamedTblFmt(finalTag)

                            while(i<textItems.length)
                            {
                                if(isTableInReferenceOrHiddenPageOrMasterPage(textItems[i].obj.TextLoc))
                                    i++
                                else
                                {
                                    var currtblfmttag = textItems[i].obj.TblTag
                                    if(currtblfmttag == iniTag)
                                    {
                                        textItems[i].obj.SetProps (newtblfmt.GetProps())
                                        tblCount++
                                     }   

                                    i++
                                }
                                
                                if(i == textItems.length)
                                    break;
                            }
                        flow = flow.NextFlowInDoc
                        }
                      //       savedoc(active);   
          }
    
}
