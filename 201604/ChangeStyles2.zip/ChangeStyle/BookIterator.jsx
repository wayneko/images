﻿/**************************************************************************/
/*
 * Program Name:                                                     
 *    << BookReportMenu.jsx  >>                                                    
 *                                              
 * Author:
 * 		Harsh Gupta (harshg@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script defines Iterator for BookReport.
 *     
 **************************************************************************/ 
 
//#include "BookReportUtils.jsx"

/*
	Book Iterator Module
*/

var BookIterator = new Object(); /* FrameMaker Internal */
BookIterator.currentComponent = null;
BookIterator.book = null;
BookIterator.func = null;
BookIterator.openBooks = null;

BookIterator.SetBook = function(bookObject)
{
	BookIterator.book = bookObject;
    BookIterator.currentComponent = null;
	BookIterator.openBooks = new Array();
	BookIterator.openBooks.push(bookObject.id);
}

BookIterator.SetCallback = function(cb)
{
       BookIterator.func = cb; 
}

BookIterator.FirstComponent = function()
{
    var firstBookComponent = BookIterator.book.FirstComponentInBook;
    BookIterator.currentComponent = firstBookComponent;
	return firstBookComponent; 
}

/* In DFS Order */
BookIterator.NextComponent = function()
{
	if(BookIterator.currentComponent == null)
    {
        return BookIterator.FirstComponent();
    }

	/*Get next component from currentComponent and currentBook */ 
	if(BookIterator.currentComponent.type == Constants.FO_BookComponent)
	{
		if(BookIterator.currentComponent.BookComponentFileType != Constants.FV_BK_BOOK)
		{
			BookIterator.currentComponent = BookIterator.currentComponent.NextBookComponentInDFSOrder;      
		}
		else
        {
			var tempComp =  BookIterator.currentComponent;   
			var tempBook = BookIterator.book;       
			
			BookIterator.currentComponent = null;                 
			var bookMode = openDoc(tempComp.Name, "");	// open tempBook Component.					
			
			if(bookMode.ObjectValid())
			{
				/* check if there is cyclic dependency. Bug# 2804616*/
				var allOpenBooks = BookIterator.openBooks.toString();
				var regExp = new RegExp(bookMode.id, "i")	// ignore case

				if(allOpenBooks.match(regExp) == null)	
				{
					/* All clear. Add entry to open book list */					
					BookIterator.openBooks.push(bookMode.id);
					BookIterator.book = bookMode;               
					BookIterator.Iterate();	
				}				
			}				
			
			BookIterator.book = tempBook;
			BookIterator.currentComponent = tempComp;                
			BookIterator.currentComponent = BookIterator.currentComponent.NextBookComponentInDFSOrder;                  
        }
    }
   
 	return BookIterator.currentComponent;
}

BookIterator.Iterate = function()
{
    var comp;
    comp = BookIterator.FirstComponent();
    
    while(comp && comp.ObjectValid())
    {
           if( comp.BookComponentFileType != Constants.FV_BK_FOLDER && 
               comp.BookComponentFileType != Constants.FV_BK_GROUP  && 
			   comp.BookComponentFileType != Constants.FV_BK_BOOK )  
           {
               if(!comp.BookComponentIsGeneratable && !comp.ExcludeBookComponent)
               {
                    BookIterator.func(comp);            
               }
           }
           comp = BookIterator.NextComponent();
    }	
}


