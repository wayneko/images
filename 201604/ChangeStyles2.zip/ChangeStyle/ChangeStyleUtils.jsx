﻿/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleUtils.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script contains Utility functions for changing styles
 *     
 **************************************************************************/

/*This function builds catalog(Para/Char/Table) from the first non generated fm/mif file in the book */
function buildCatalogFromBook(builder)
{
    var activeBook = findActive ()
    var comp = activeBook.FirstComponentInBook 
   
    while(comp.ObjectValid())
    {
            var compType=comp.BookComponentFileType    
            if(comp.BookComponentIsGeneratable == false && (compType == 8 || compType == 16))
                break;
            else
                comp = comp.NextBookComponentInDFSOrder
     }
 
    if(comp.ObjectValid())
       {  
           var flag = 0;
           compType=comp.BookComponentFileType
           if(compType == Constants.FV_BK_MIF || compType == Constants.FV_BK_FM) 
          {    
                var currDoc = app.FirstOpenDoc
                while(currDoc.ObjectValid())
                {
                        if(currDoc.Name == comp.Name )
                        {  
                            flag = 1;
                            var doc = currDoc
                            break;
                         }   
                        else
                            currDoc = currDoc.NextOpenDocInSession
                 }
                if(!flag)
                    doc = openDoc(comp.Name)
                    
                buildCatalogFromDoc(builder,doc)
                
                if(!flag)
                    closeDoc(doc)
                
                return
           }
        }   
    else
        return
}

/*This function builds catalog(Para/Char/Table) from the  fm/mif file */ 

/*
 * This function builds catalog(Para/Char/Table) from the  fm/mif file
 * builder: Change Style UI
  * active: Active Document
 */
function buildCatalogFromDoc(builder,active)
{
 
 clearDropDown(builder)  
 switch(type) 
	{
        case "para": 
                                   
                    var list = getParaTagList(active)        
                    addToDropDown(builder,list)
                    break;
                    
         case "char":       
                        
                    var list = getCharTagList(active)        
                    addToDropDown(builder,list)
                    break;
           
           case "table":       
                        
                   var list = getTblFmtList(active)        
                   addToDropDown(builder,list)
                   break;
                    
           }
       return        
}

/*Get Paragraph Format List from the active document and return that list*/
function getParaTagList(active)
{
    var list = new Array()
    var tag = active.FirstPgfFmtInDoc
    var tagname = tag.Name
    var counter = 0
    
    while(tag.ObjectValid())
            {
                            list[counter] = tagname 
                            tag = tag.NextPgfFmtInDoc
                            tagname = tag.Name
                            counter++
            }
       return list
}

/*Get Character Format List from the active document and return that list*/
function getCharTagList(active)
{
    var list = new Array
    var tag = active.FirstCharFmtInDoc
    var tagname = tag.Name
    var counter = 0
    
    while(tag.ObjectValid())
            {
                            list[counter] = tagname
                            tag = tag.NextCharFmtInDoc
                            tagname = tag.Name
                            counter++
            }
       return list
}

/*Get Table Format List from the active document and return that list*/
function getTblFmtList(active)
{
    var list = new Array
    var tag = active.FirstTblFmtInDoc
    var tagname = tag.TblTag
    var counter = 0
    
    while(tag.ObjectValid())
            {
                            list[counter] = tagname
                            tag = tag.NextTblFmtInDoc
                            tagname = tag.TblTag
                            counter++
            }
       return list
}


/*This function iterates through the book */
function iterateBook(activeBook) 
{  
    BookIterator.SetBook(activeBook);
    BookIterator.SetCallback(changeTagInBookComponent);
    BookIterator.Iterate();
 }

/*This function and changes the format in mif/fm files in book*/
function changeTagInBookComponent(comp)
{	
    var compType = comp.BookComponentFileType
    var docName = comp.Name
        doc = openDoc(docName)
		if(compType == Constants.FV_BK_MIF || compType == Constants.FV_BK_FM)
        {
               if(type == "para") 
                    changeParaTag(doc)  
               else  if(type == "char") 
                    changeCharTag(doc) 
                else  if(type == "table") 
                    changeTblTag(doc)
                
                if(!fileWasAlreadyOpen)
                {
                    saveDoc(doc)
                    closeDoc(doc)
                }    
         }	
 }


/*This function opens the fm/mif file in the book in invisible mode*/
function openDoc(filename)
{
    var openparams = GetOpenDefaultParams()
    var index

	index = GetPropIndex(openparams, Constants.FS_FileIsOldVersion);
	openparams[index].propVal.ival = Constants.FV_DoOK;
	
	index = GetPropIndex(openparams, Constants.FS_AlertUserAboutFailure);
	openparams[index].propVal.ival = 0;

	index = GetPropIndex(openparams, Constants.FS_MakeVisible);
	openparams[index].propVal.ival = 0;

	index = GetPropIndex(openparams, Constants.FS_BookIsInUse);
	openparams[index].propVal.ival = Constants.FV_ResetLockAndContinue;

	index = GetPropIndex(openparams, Constants.FS_FileIsInUse);
	openparams[index].propVal.ival = Constants.FV_ResetLockAndContinue;

	index = GetPropIndex(openparams, Constants.FS_FileIsText);
	openparams[index].propVal.ival = Constants.FV_TextFile_EOLisEOP;

	index = GetPropIndex(openparams, Constants.FS_FontChangedMetric);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_FontNotFoundInCatalog);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_FontNotFoundInDoc);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_LanguageNotAvailable);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_LockCantBeReset);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_OpenFileNotWritable);
	openparams[index].propVal.ival = Constants.FV_DoOK;

	index = GetPropIndex(openparams, Constants.FS_RefFileNotFound);
	openparams[index].propVal.ival = Constants.FV_AllowAllRefFilesUnFindable;

	index = GetPropIndex(openparams, Constants.FS_UseAutoSaveFile);
	openparams[index].propVal.ival = Constants.FV_DoNo;

	index = GetPropIndex(openparams, Constants.FS_UseRecoverFile);
	openparams[index].propVal.ival = Constants.FV_DoNo;
    
    index=GetPropIndex(openparams,Constants.FS_MakeVisible)
    openparams[index].propVal.ival="False"

    var retParm = new PropVals()
    docOpen=Open(filename,openparams,retParm)
    
    fileWasAlreadyOpen = CheckStatus(retParm, Constants.FV_FileAlreadyOpen)
    
    return docOpen
}

/*This function closes the active document*/
function closeDoc(activeDoc)
{
		activeDoc.Close(1)
	
}

/*This function saves the active document */
function saveDoc(docId)

{
	    var params = GetSaveDefaultParams()
		var returnParamsp =new PropVals()
        
		var i = GetPropIndex(params, Constants.FS_FileType)
		params[i].propVal.ival =Constants.FV_SaveFmtBinary
        
		docId.Save(docId.Name, params, returnParamsp)
		return	
}

/*This function creates a new text range in a paragraph*/
function createTextRange(begr,endr,currPgf)
{
        
    var tr = new TextRange()

    tr.beg.obj = currPgf
    tr.beg.offset = begr

    tr.end.obj = currPgf
    tr.end.offset = endr

    return tr
}

/*This function finds whether a document/book is active and returns the active one.*/
function findActive()
{
    var activeDocument = app.ActiveDoc
    var activeBook = app.ActiveBook
    
    if(activeDocument.ObjectValid())
        return activeDocument
    else if(activeBook.ObjectValid())
        return activeBook
    else 
        return null  
 }

/*This function sets the type of change -- Para/Char/Table*/
function setType(changeType)
{
        type = changeType
}


/*This function returns the page type of a text location*/
function getTextLocPageType(textLoc)
{
	var inPageType = Constants.FO_Bad;
	
	if(textLoc.obj.ObjectValid())
	{
		var parentFrame = textLoc.obj.InTextFrame;
		var parentType = parentFrame.type;
		
		while(parentType != Constants.FO_BodyPage
			&& parentType != Constants.FO_MasterPage
			&& parentType != Constants.FO_HiddenPage
			&& parentType != Constants.FO_RefPage)
		{
			var oldParentFrame = parentFrame;
			parentFrame = parentFrame.FrameParent;
			
			if(!parentFrame.ObjectValid())
			{
				parentFrame = oldParentFrame.PageFramePage;
				
				if(!parentFrame.ObjectValid())
					break;
			}
			
			parentType = parentFrame.type;
		}
	
		inPageType = parentType;
    }
	
	return inPageType;
}

/*This functions returns whether a location is in which page*/
function isTableInReferenceOrHiddenPageOrMasterPage(textLoc)
{
    var pageType = getTextLocPageType(textLoc);
    
	return ( pageType == Constants.FO_RefPage) ||
			(pageType == Constants.FO_HiddenPage) ||
            (pageType == Constants.FO_MasterPage);
}