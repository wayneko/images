﻿/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleUI.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script contains UI functions to change styles.
 *     
 **************************************************************************/
/*This function creates the UI for choosing the initial and final format and to apply these changes*/
function createDlg()
{      
            var active = findActive ();
            var dlg = new Window('dialog', 'Change Styles');
            dlg.alertBtnsPnl = dlg.add('panel', undefined, 'Styles');
            dlg.alertBtnsPnl.orientation = "row";
            dlg.alertBtnsPnl.alignLeftRb = dlg.alertBtnsPnl.add('radiobutton',
            undefined, 'Para Style');
            dlg.alertBtnsPnl.alignCenterRb = dlg.alertBtnsPnl.add('radiobutton',
            undefined, 'Char Style');
            dlg.alertBtnsPnl.alignRightRb = dlg.alertBtnsPnl.add('radiobutton',
            undefined, 'Table Style');
            dlg.alertBtnsPnl.alignLeftRb.value = true;
            
           
              dlg.msgPnl = dlg.add('panel', undefined, 'Change From :');
			dlg.msgPnl.alignChildren = "right";
			// add the panel's child components
			dlg.msgPnl.title = dlg.msgPnl.add('group');
			dlg.msgPnl.msg = dlg.msgPnl.add('group');
			dlg.msgPnl.msgWidth = dlg.msgPnl.add('group');
			dlg.msgPnl.msgHeight = dlg.msgPnl.add('group');		
			
		with (dlg.msgPnl) 
        {
               title.st = title.add("statictext{text: 'Find:'}")  
               title.et = title.add("dropdownlist { }");
               title.et.preferredSize = [176,25];
                      
               msg.st = msg.add("statictext{text: 'Change:'}")  
               msg.et = msg.add("dropdownlist { }");
               msg.et.preferredSize = [176,25];
                 
                // Add a panel with buttons to test parameters and
                dlg.btnPnl = dlg.add('group', undefined, '');
                dlg.btnPnl.orientation = "row";
                dlg.btnPnl.testBtn = dlg.btnPnl.add('button', undefined, 'Change ');
                dlg.btnPnl.cancelBtn = dlg.btnPnl.add('button', undefined, 'Cancel', {name:'cancel'});
            }
        
         with(dlg.alertBtnsPnl)
        { 
            setType("para")  
            if(active.BookIsSelected || active.FirstSelectedComponentInBook)   
            {     
                   buildCatalogFromBook(dlg)
            }
            else
            {       
                   buildCatalogFromDoc(dlg,active)
            }     
        }
        
       
    return dlg
}

/*This function controls the behaviour of the radio buttons and buttons*/
function initializeBuilder(builder)
{
   var active = findActive ()
     
    with (builder.btnPnl) {
			
			testBtn.onClick = function ()
			{
                iniTag = builder.msgPnl.title.et.selection.text
                finalTag = builder.msgPnl.msg.et.selection.text
            

			this.parent.parent.close(2)
                
                if(builder.alertBtnsPnl.alignLeftRb.value)
                {
                    changeParaTag(active)
                    Err("\nNumber of paragraphs for which format "+iniTag+" was changed to format "+finalTag +" = "+paraCount)
                    alert("Number of paragraphs for which format "+iniTag+" was changed to format "+finalTag +" = "+paraCount)
                    paraCount = 0
                 }   
                else if(builder.alertBtnsPnl.alignRightRb.value)
                {
                    
				  changeTblTag(active)
                    Err("\nNumber of tables for which format "+iniTag+" was changed to format "+finalTag +" = "+tblCount)
                    alert("Number of tables for which format "+iniTag+" was changed to format "+finalTag +" = "+tblCount)
                    tblCount = 0   
                     
                }   
                else if(builder.alertBtnsPnl.alignCenterRb.value)
                {
				   changeCharTag(active)
                     Err("\nNumber of characters for which format "+iniTag+" was changed to format "+finalTag +" = "+charCount)
                     alert("Number of characters for which format "+iniTag+" was changed to format "+finalTag +" = "+charCount)
                     charCount = 0
                 }
				
			}

			// The Cancel buttons close this dialog
			cancelBtn.onClick = function () { this.parent.parent.close(2) }
		}
          
    with(builder.alertBtnsPnl){
        
                   alignLeftRb.onClick = function()
                    {
                          setType("para")      
                          if(active.BookIsSelected || active.FirstSelectedComponentInBook)      
                            buildCatalogFromBook(builder)
                         else
                            buildCatalogFromDoc(builder,active)
                    }
                    alignRightRb.onClick = function()
                    {
                           setType("table")       
                          if(active.BookIsSelected || active.FirstSelectedComponentInBook)      
                            buildCatalogFromBook(builder)
                         else
                            buildCatalogFromDoc(builder,active)
                    }
                    alignCenterRb.onClick = function()
                    {
                         setType("char") 
                        if(active.BookIsSelected || active.FirstSelectedComponentInBook)      
                            buildCatalogFromBook(builder)
                         else
                            buildCatalogFromDoc(builder,active)
                     }
                }
 }

/*This function adds a list to the dropdown*/
function addToDropDown(builder,list)
{
    var counter = 0
    while(counter<list.length)
    {
           builder.msgPnl.title.et.add ('item',list[counter])
           builder.msgPnl.msg.et.add ('item',list[counter])
           counter++
     }

}

/*This function clears the existing items in the dropdown.*/
function clearDropDown(builder)
{
                  builder.msgPnl.title.et.removeAll() 
                  builder.msgPnl.msg.et.removeAll()
                  
                  builder.msgPnl.title.et.add ('item','Select')
				builder.msgPnl.msg.et.add ('item','Select')
				builder.msgPnl.msg.et.selection = builder.msgPnl.msg.et.items[0]
				builder.msgPnl.title.et.selection = builder.msgPnl.title.et.items[0]
}

/*This function displays the UI on the screen*/
function runBuilder(builder) 
{
		return builder.show();
}

