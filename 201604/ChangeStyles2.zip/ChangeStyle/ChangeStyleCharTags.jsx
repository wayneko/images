﻿/*************************************************************************/
/*                                                                                                                      */
/* ADOBE SYSTEMS INCORPORATED                                                   */
/* Copyright 1986 - 2011 Adobe Systems Incorporated                        */
/* All Rights Reserved                                                                                  */
/*                                                                                                                      */
/* NOTICE:  Adobe permits you to use, modify, and distribute this      */
/* file in accordance with the terms of the Adobe license agreement */
/* accompanying it.  If you have received this file from a source           */
/* other than Adobe, then your use, modification, or distribution          */
/* of it requires the prior written permission of Adobe.                            */
/*                                                                                                                        */
/**************************************************************************/
/*
 * Program Name:                                                     
 *    << ChangeStyleCharTags.jsx  >>                                                    
 *                                              
 * Author:
 * 		Bharat Prakash (bharatp@adobe.com)
 *                                                                   
 * General Description:                                              
 *    This script contains functions to change character style
 *     
 **************************************************************************/ 

/*This function changes character tags in a document on all flows.*/

function changeCharTag(active)
{
    
     if(active.BookIsSelected || active.FirstSelectedComponentInBook) 
        iterateBook(active); 
    else if(active.ObjectValid())
        {
            
            var flow = active.FirstFlowInDoc;
            while(flow.ObjectValid())        
              {       
                    var firstPgf = flow.FirstTextFrameInFlow.FirstPgf
                    var currPgf = firstPgf
                    changeCharStyleInPgf(currPgf,active)
                    changeCharStyleInTbl(flow,active) 
                    flow = flow.NextFlowInDoc
               }   
          }
            
       //          savedoc(active);   
}

/*This function changes character tags in a table.*/

function changeCharStyleInTbl(flow,active)
{
        var textItems = flow.GetText(Constants.FTI_TblAnchor);
        var j = 0;

        while(j<textItems.length)
        {
            var tbl = textItems[j].obj
            if(isTableInReferenceOrHiddenPageOrMasterPage(textItems[j].obj.TextLoc))
                j++
            else
            {
                var currRow = tbl.FirstRowInTbl
                changeCharStyleInRow(currRow,active)
                currRow = currRow.NextRowInTbl
                j++     
            }
         }
}

/*This function changes character tags for the textrange in a paragraph*/

function setCharTagInPgf(currTextRange,active)
{  
    var newFmtObj = active.GetNamedCharFmt(finalTag)
    if(newFmtObj.Name != null )
   { 
        var newFmtProps = newFmtObj.GetProps()
        active.SetTextProps (currTextRange, newFmtProps) 
    }
}

/*This function changes character tags in a row of a table.*/

function changeCharStyleInRow(currRow,active)
{
    while(currRow.ObjectValid())
                {
                          var currCell = currRow.FirstCellInRow
                          changeCharStyleInCell(currCell,active)
                          currRow = currRow.NextRowInTbl 
                 }
 }

/*This function changes character tags in a cell of a table.*/

function changeCharStyleInCell(currCell,active)
{
    while(currCell.ObjectValid())
                          {
                                var currPgf = currCell.FirstPgf
                                changeCharStyleInPgf(currPgf,active)
                                currCell = currCell.NextCellInRow
                           }
}

/*This function changes character tags in paragraph.*/

function changeCharStyleInPgf(currPara,active)
{     
    var textloc = new TextLoc(currPara,0) 
    if(!isTableInReferenceOrHiddenPageOrMasterPage(textloc))
        while(currPara.ObjectValid())
                                { 
                                    var i = 0
                                    var items = currPara.GetText(Constants.FTI_String)    
                                    while(i<items.length)
                                                {                                                
                                                        var boff = items[i].offset
                                                        var eoff = boff+items[i].sdata.length
                                                        var temptextloc = new TextLoc(currPara,boff) 
                                                        var currcharfmt = active.GetTextPropVal (temptextloc,Constants.FP_CharTag)
                                                        if(currcharfmt.propVal.sval == iniTag && currcharfmt.propIdent.num != 0)
                                                               {  
                                                                        var currTextRange = createTextRange(boff,eoff,currPara);
                                                                        setCharTagInPgf(currTextRange,active)
                                                                        charCount = charCount+eoff-boff
                                                               }
                                                              
                                                     i++
                                                  }
                                       currPara = currPara.NextPgfInFlow  
                                 } 
 }